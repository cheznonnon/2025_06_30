//
//  AppDelegate.m
//  Nonnon CatPad
//
//  Created by のんのん on 2022/08/14.
//


#import "AppDelegate.h"


#include "../../nonnon/mac/n_txtbox.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/n_button.c"

#include "../../nonnon/neutral/bmp/ui/search_icon.c"


#include "catpad_filter.c"




void
n_catpad_txt2html( n_txt *txt )
{

	int i = 0;
	while( 1 )
	{

		n_txt_mod_fast( txt, i, n_string_tab2space( txt->line[ i ], 8, NULL ) );

		txt->line[ i ] = n_memory_resize( txt->line[ i ], 1024 );

		n_string_replace( txt->line[ i ], txt->line[ i ], "&" , "&amp;"        );
		n_string_replace( txt->line[ i ], txt->line[ i ], ">" , "&gt;"         );
		n_string_replace( txt->line[ i ], txt->line[ i ], "<" , "&lt;"         );
		n_string_replace( txt->line[ i ], txt->line[ i ], "  ", "&nbsp;&nbsp;" );


		i++;
		if ( i >= txt->sy ) { break; }
	}


	return;
}




@interface CatPadDrag: NSView
@end

@implementation CatPadDrag

/*
- (void)drawRect:(NSRect)rect
{
NSLog(@"drawRect");

	NSColor *color = n_mac_nscolor_argb( 255, 0,200,255 );
	n_mac_draw_box( color, rect );
}
*/

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( theEvent.clickCount >= 2 )
	{
		[self.window zoom:self.window];

		return;
	}

	[self.window performWindowDragWithEvent:theEvent];

}

@end




static AVAudioPlayer *player;




@interface AppDelegate : NSObject <NSApplicationDelegate, NonnonTxtbox_delegate>
@end


@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonTxtbox *n_txtbox;

@property (weak) IBOutlet NonnonButton *n_button_top;
@property (weak) IBOutlet NonnonButton *n_button_save;
@property (weak) IBOutlet NonnonButton *n_button_frmt;
@property (weak) IBOutlet NonnonButton *n_button_calc;
@property (weak) IBOutlet NonnonButton *n_button_dump;
@property (weak) IBOutlet NonnonButton *n_button_html;

@property (weak) IBOutlet NonnonTxtbox *n_search;

@property (weak) IBOutlet NSWindow   *n_formatter_window;
@property (weak) IBOutlet NSComboBox *n_formatter_combo_charset;
@property (weak) IBOutlet NSComboBox *n_formatter_combo_newline;

@property (weak) IBOutlet NSWindow    *n_volume_window;
@property (weak) IBOutlet NSTextField *n_volume_label;
@property (weak) IBOutlet NSSlider    *n_volume_slider;

@property n_txt n_txt_data;
@property n_txt n_txt_search_data;


@end




@implementation AppDelegate {

	BOOL  topmost_onoff;
	BOOL     dump_onoff;
	BOOL     html_onoff;

	BOOL   n_sheet_used;

	int   blink;

	n_bmp search_icon;

	int   volume;

}


@synthesize n_txt_data;
@synthesize n_txt_search_data;




- (instancetype)init
{
	self = [super init];
	if ( self )
	{
		n_sheet_used = YES;

		n_txt_zero( &n_txt_data );

		n_txt_data.unicode = N_TXT_UNICODE_UTF8_NO_BOM;
		n_txt_data.newline = N_TXT_NEWLINE_LF;

		n_txt_utf8_new( &n_txt_data );

		n_txt_zero( &n_txt_search_data );
		n_txt_utf8_new( &n_txt_search_data );

		blink = 0;
		n_mac_timer_init( self, @selector( NonnonCatPadBlinkTimer ), 100 );
	}
	
	return self;
}

- (BOOL)application:(NSApplication *)sender
           openFile:(NSString *)filename
{
	return [_n_txtbox n_txtbox_open:filename];
}




- (void) NonnonCatPadVolumeLabel : (int) vol
{

	NSString *nsstr = [NSString stringWithFormat:@"Volume %d%%", vol];

	_n_volume_label.stringValue = nsstr;

}

- (void) NonnonCatPadSettings : (BOOL) is_read
{

	NSString *nsstr;

	if ( is_read )
	{

		nsstr = n_mac_settings_read( @"find" );
		if ( nsstr.length == 0 ) { nsstr = [NSString stringWithFormat:@""]; }

		n_posix_char *str = n_mac_nsstring2str( nsstr );

		n_txt_set( _n_search.n_txt_data, 0, str );

		[_n_search NonnonTxtboxCaretTailSet];

		n_string_free( str );


		// [!] : In-App Volume

		nsstr = n_mac_settings_read( @"volume" );
		if ( nsstr.length == 0 ) { nsstr = [NSString stringWithFormat:@"80"]; }

		volume = (int) [nsstr integerValue];
		[self NonnonCatPadVolumeLabel:volume];

	} else {

		nsstr = n_mac_str2nsstring( n_txt_get( _n_search.n_txt_data, 0 ) );
		n_mac_settings_write( @"find", nsstr );

		// [!] : In-App Volume

		nsstr = [NSString stringWithFormat:@"%d", volume];
		n_mac_settings_write( @"volume", nsstr );

//nsstr = n_mac_settings_read( @"find" );
//NSLog( @"string : %@", nsstr );

	}

}




- (void) NonnonCatPadTitle
{
	NSString *nsstr = [NSString stringWithFormat:@"%@ - CatPad", _n_txtbox.n_path];
	[_window setTitle:nsstr];
}




- (void) NonnonCatPadReadOnly
{

	if (
		( n_txt_data.unicode == N_TXT_UNICODE_NIL )
		||
		( n_txt_data.newline == N_TXT_NEWLINE_BINARY )
	)
	{
		n_txt_data.readonly = n_posix_true;
	} else {
		n_txt_data.readonly = n_posix_false;
	}

}




- (void) NonnonCatPadIconHighRes:(n_bmp*) bmp_icon
{

	if ( 32 >= N_BMP_SX( bmp_icon ) ) { return; }


	n_posix_loop
	{
		if ( 32 >= N_BMP_SX( bmp_icon ) ) { break; }

		n_bmp_flush_antialias( bmp_icon, 1.0 );
		n_bmp_scaler_lil( bmp_icon, 2 );
	}

	n_bmp_flush_replacer( bmp_icon, n_bmp_white_invisible, n_bmp_black );
	n_bmp_alpha_visible( bmp_icon );
	n_bmp_flush_replacer( bmp_icon, n_bmp_black, n_bmp_white_invisible );

	n_bmp_flush_sharpen( bmp_icon, 0.125 );

}

- (void) NonnonCatPadNekoChange:(int)mode
{

	n_bmp bmp_icon; n_bmp_zero( &bmp_icon );

	if ( mode == 0 )
	{
		n_mac_image_rc_load_bmp( @"neko_sleeping", &bmp_icon );
	} else
	if ( mode == 1 )
	{
		n_mac_image_rc_load_bmp( @"neko_half", &bmp_icon );
	} else
	if ( mode == 2 )
	{
		n_mac_image_rc_load_bmp( @"neko", &bmp_icon );
	}

	[self NonnonCatPadIconHighRes:&bmp_icon];

	[_n_button_save n_icon_free];
	[_n_button_save n_icon_set:&bmp_icon];

}

- (void) NonnonCatPadNekoAlternation:(BOOL)onoff
{

	[_n_button_save n_enable:onoff];

	if ( onoff )
	{
		[self NonnonCatPadNekoChange:2];
	} else {
		[self NonnonCatPadNekoChange:0];
	}


}

- (void) NonnonCatPadBlinkTimer
{
//NSLog( @"NonnonCatPadBlinkTimer : %d", [_n_button_save n_is_enabled] );

	if ( [_n_button_save n_is_enabled] == FALSE ) { return; }

//NSLog( @"NonnonCatPadBlinkTimer : %d", blink );

	blink++;
	if ( blink == 47 )
	{
//NSLog( @"on" );
		[self NonnonCatPadNekoChange: 1 ];
		[_n_button_save display];
	} else
	if ( blink == 48 )
	{
//NSLog( @"on" );
		[self NonnonCatPadNekoChange: 0 ];
		[_n_button_save display];
	} else
	if ( blink == 49 )
	{
//NSLog( @"on" );
		[self NonnonCatPadNekoChange: 1 ];
		[_n_button_save display];
	} else
	if ( blink == 50 )
	{
//NSLog( @"off" );
		[self NonnonCatPadNekoChange: 2 ];
		[_n_button_save display];

		blink = 0;
	}
	
}

- (void) NonnonCatPadIconSet:(NonnonButton*)button rc:(NSString*)name
{

	n_bmp bmp_icon; n_bmp_zero( &bmp_icon );

	n_mac_image_rc_load_bmp( name, &bmp_icon );

	n_mac_button_system_themed( &bmp_icon );

	[self NonnonCatPadIconHighRes:&bmp_icon];


	[button n_icon_set:&bmp_icon];
	[button display];

}

- (void) NonnonCatPadMeow
{

	player = n_mac_sound_wav_init( @"Cat Meow" );

	player.volume = (CGFloat) volume * 0.01;

	n_mac_sound_play( player );

}




- (void)awakeFromNib
{
//NSLog( @"awakeFromNib" );

	// [!] : macOS 12 Monterey needs this
	[_window setFrameAutosaveName:@"Nonnon.CatPad"];


	n_mac_image_window = _window;


	BOOL border_onoff = FALSE;

	{
		[self NonnonCatPadIconSet:_n_button_top rc:@"top"];

		[_n_button_top n_enable:TRUE];
		[_n_button_top n_border:border_onoff];
		[_n_button_top n_nswindow_set:_window];

		_n_button_top.delegate = self;

		topmost_onoff = FALSE;
	}

	{
		[self NonnonCatPadNekoAlternation:FALSE];

		[_n_button_save n_border:border_onoff];
		[_n_button_save n_nswindow_set:_window];

		_n_button_save.delegate       = self;
		_n_button_save.delegate_right = self;
	}

	{
		[self NonnonCatPadIconSet:_n_button_frmt rc:@"config"];

		[_n_button_frmt n_enable:TRUE];
		[_n_button_frmt n_border:border_onoff];
		[_n_button_frmt n_nswindow_set:_window];

		_n_button_frmt.delegate = self;
	}

	{
		[self NonnonCatPadIconSet:_n_button_calc rc:@"calc_nonnon"];

		[_n_button_calc n_enable:TRUE];
		[_n_button_calc n_border:border_onoff];
		[_n_button_calc n_nswindow_set:_window];

		_n_button_calc.delegate = self;
	}

	{
		[self NonnonCatPadIconSet:_n_button_dump rc:@"ndump"];

		[_n_button_dump n_enable:TRUE];
		[_n_button_dump n_border:border_onoff];
		[_n_button_dump n_nswindow_set:_window];

		_n_button_dump.delegate = self;

		dump_onoff = FALSE;
	}

	{
		[self NonnonCatPadIconSet:_n_button_html rc:@"html"];

		[_n_button_html n_enable:TRUE];
		[_n_button_html n_border:border_onoff];
		[_n_button_html n_nswindow_set:_window];

		_n_button_html.delegate = self;

		html_onoff = FALSE;
	}


	_n_txtbox.delegate_option         = N_MAC_TXTBOX_DELEGATE_ALL;
	_n_txtbox.delegate                = self;
	_n_txtbox.n_txt_data              = &n_txt_data;
	_n_txtbox.n_mode                  = N_MAC_TXTBOX_MODE_EDITBOX;
	_n_txtbox.n_option_linenumber     = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;
	_n_txtbox.n_corner_size           = -1;
	_n_txtbox.n_direct_click_onoff    = TRUE;
	_n_txtbox.n_border_separator_only = TRUE;

	[_n_txtbox NonnonTxtboxReset];

	_n_search.delegate_option      = N_MAC_TXTBOX_DELEGATE_ALL;
	_n_search.delegate             = self;
	_n_search.n_txt_data           = &n_txt_search_data;
	_n_search.n_mode               = N_MAC_TXTBOX_MODE_FINDBOX;
	_n_search.n_focus              = 0;
	_n_search.n_option_linenumber  = N_MAC_TXTBOX_DRAW_LINENUMBER_NONE;
	_n_search.n_direct_click_onoff = TRUE;

	NSFont *font = n_mac_stdfont();

	[_n_search NonnonTxtboxFontChange:font];

	{
		n_bmp_zero( &search_icon );
		n_bmp_ui_search_icon_make( &search_icon, 1024, 0, n_bmp_black );

		_n_search.n_findbox_bmp_icon = &search_icon;
	}

	[_n_search NonnonTxtboxReset];

	[self NonnonCatPadSettings:YES];


	[[_n_txtbox window] makeFirstResponder:_n_txtbox];


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( accentColorChanged: )
		       name: @"AppleColorPreferencesChangedNotification"
		     object:nil
	];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}

- (void) accentColorChanged:(NSNotification *)notification
{
//NSLog( @"accentColorChanged" );

	[self NonnonCatPadIconSet:_n_button_top  rc:@"top"        ];
	[self NonnonCatPadIconSet:_n_button_frmt rc:@"config"     ];
	[self NonnonCatPadIconSet:_n_button_calc rc:@"calc_nonnon"];
	[self NonnonCatPadIconSet:_n_button_dump rc:@"ndump"      ];
	[self NonnonCatPadIconSet:_n_button_html rc:@"html"       ];

}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}




- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");
}

- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog(@"mouseUp");
//return;

//NSLog( @"mouseUp : %@", _n_txtbox.n_path );

	if ( [_n_button_top n_is_pressed] )
	{
//NSLog(@"mouseUp");

		if ( topmost_onoff )
		{
			topmost_onoff = FALSE;
		} else {
			topmost_onoff = TRUE;
		}

		n_mac_topmost( _window, topmost_onoff );

		[_n_button_top n_fake:topmost_onoff];
		[_n_button_top display];

	} else
	if ( [_n_button_save n_is_pressed] )
	{

		n_posix_char *fname = n_mac_nsstring2str( _n_txtbox.n_path );
//NSLog( @"Name : %s", fname );

		if ( n_txt_save_utf8( &n_txt_data, fname ) )
		{
//NSLog( @"not saved" );
			// [!] : error

			// [x] : crash without "App Sandbox" "User Selected File"

			NSString *name = [_n_txtbox.n_path lastPathComponent];

			NSSavePanel *panel = [NSSavePanel savePanel];
   			[panel setNameFieldStringValue:name];
			[panel beginSheetModalForWindow:_window completionHandler:^(NSInteger result)
			{
				if ( result == NSModalResponseOK )
				{
					NSString     *nsstring = [[panel URL] path];
					n_posix_char *str      = n_mac_nsstring2str( nsstring );

					n_posix_bool ret = n_txt_save_utf8( &self->n_txt_data, str );
					if ( ret == n_posix_false )
					{
						self->_n_txtbox.n_path = nsstring;

						[self NonnonCatPadMeow];

						[self NonnonCatPadTitle];
					}

					[self NonnonCatPadReadOnly];

					n_string_free( str );

					[self NonnonCatPadNekoAlternation:FALSE];
					[self->_n_button_save display];

					[self->_n_button_dump n_enable:TRUE];
					[self->_n_button_dump display];

					[self->_n_button_html n_enable:TRUE];
					[self->_n_button_html display];
				}

			}];

		} else {

			[self NonnonCatPadNekoAlternation:FALSE];
			[_n_button_save display];

			[_n_button_dump n_enable:TRUE];
			[_n_button_dump display];

			[_n_button_html n_enable:TRUE];
			[_n_button_html display];

			[self NonnonCatPadMeow];

			[self NonnonCatPadTitle];

		}

		n_string_free( fname );

	} else
	if ( [_n_button_frmt n_is_pressed] )
	{

		if ( n_txt_data.unicode == N_TXT_UNICODE_LIL )
		{
			[_n_formatter_combo_charset selectItemAtIndex:0];
		} else
		if ( n_txt_data.unicode == N_TXT_UNICODE_BIG )
		{
			[_n_formatter_combo_charset selectItemAtIndex:1];
		} else
		if ( n_txt_data.unicode == N_TXT_UNICODE_UTF )
		{
			[_n_formatter_combo_charset selectItemAtIndex:2];
		} else
		if ( n_txt_data.unicode == N_TXT_UNICODE_UTF8_NO_BOM )
		{
			[_n_formatter_combo_charset selectItemAtIndex:3];
		}// else

		if ( n_txt_data.newline == N_TXT_NEWLINE_CRLF )
		{
			[_n_formatter_combo_newline selectItemAtIndex:0];
		} else
		if ( n_txt_data.newline == N_TXT_NEWLINE_CR )
		{
			[_n_formatter_combo_newline selectItemAtIndex:1];
		} else
		if ( n_txt_data.newline == N_TXT_NEWLINE_LF )
		{
			[_n_formatter_combo_newline selectItemAtIndex:2];
		}// else

		if ( n_sheet_used )
		{
			[_window beginSheet:_n_formatter_window completionHandler:^(NSModalResponse returnCode)
			{
				//
			}
			];
		} else {
			n_mac_window_show( _n_formatter_window );
			[_n_formatter_window makeKeyWindow];
		}

	} else
	if ( [_n_button_calc n_is_pressed] )
	{

		NSArray *args = [NSArray arrayWithObjects:@"-a", @"Calculator", nil];
		NSTask  *task = [NSTask new];
		[task setLaunchPath:@"/usr/bin/open"];
		[task setArguments:args];

		[task launch];

	} else
	if ( [_n_button_dump n_is_pressed] )
	{

		if ( [_n_button_save n_is_enabled] ) { return; }

		if ( dump_onoff )
		{
			dump_onoff = FALSE;

			n_posix_char *str = n_mac_nsstring2str( _n_txtbox.n_path );

			n_txt_load_utf8( &n_txt_data, str );

			[_n_txtbox NonnonTxtboxReset];
			[_n_txtbox NonnonTxtboxUndo:N_TXTBOX_UNDO_RESET];

			n_string_free( str );

			[self NonnonCatPadReadOnly];

			[_n_txtbox NonnonTxtboxRedraw];
		} else {
			dump_onoff = TRUE;

			n_posix_char *str = n_mac_nsstring2str( _n_txtbox.n_path );

			n_catpad_ntxt_dump( &n_txt_data, str );

			n_string_free( str );

			n_txt_data.readonly = n_posix_true;

			[_n_txtbox NonnonTxtboxRedraw];
		}

		[_n_button_dump n_fake:dump_onoff];
		[_n_button_dump display];

		[_n_button_html n_enable:( ( dump_onoff == FALSE )&&( n_txt_data.readonly == n_posix_false ) )];
		[_n_button_html display];

	} else
	if ( [_n_button_html n_is_pressed] )
	{

		if ( [_n_button_save n_is_enabled] ) { return; }


		if ( html_onoff )
		{
			html_onoff = FALSE;

			n_posix_char *str = n_mac_nsstring2str( _n_txtbox.n_path );

			n_txt_load_utf8( &n_txt_data, str );

			[_n_txtbox NonnonTxtboxReset];
			[_n_txtbox NonnonTxtboxUndo:N_TXTBOX_UNDO_RESET];

			n_string_free( str );

			[self NonnonCatPadReadOnly];

			[_n_txtbox NonnonTxtboxRedraw];
		} else {
			html_onoff = TRUE;

			n_catpad_txt2html( &n_txt_data );

			n_txt_data.readonly = n_posix_true;

			[_n_txtbox NonnonTxtboxRedraw];
		}

		[_n_button_html n_fake:html_onoff];
		[_n_button_html display];

		[_n_button_dump n_enable:( html_onoff == FALSE )];
		[_n_button_dump display];

	}

}

- (void) rightMouseUp:(NSEvent*) theEvent
{
//NSLog(@"rightMouseUp");

	if ( [_n_button_save n_is_pressed_right] )
	{
//NSLog( @"rightMouseUp" );

		[self NonnonCatPadVolumeLabel:volume];
		_n_volume_slider.integerValue = volume;

		[_window beginSheet:_n_volume_window completionHandler:^(NSModalResponse returnCode)
		{
			//
		}
		];

	}

}

- (void) rightMouseDown:(NSEvent*) theEvent
{
//NSLog(@"rightMouseDown");
}




- (void) NonnonTxtbox_delegate_dropped
{
//NSLog( @"%d", n_txt_data.readonly );

	[self NonnonCatPadReadOnly];


	[self NonnonCatPadNekoAlternation:FALSE];
	[_n_button_save display];


	dump_onoff = FALSE;

	[_n_button_dump n_enable:TRUE];
	[_n_button_dump n_fake :FALSE];

	[_n_button_dump display];


	html_onoff = FALSE;

	[_n_button_html n_enable:( n_txt_data.readonly == n_posix_false )];
	[_n_button_html n_fake :FALSE];

	[_n_button_html display];


	if (
		( n_txt_data.newline == N_TXT_NEWLINE_BINARY )
		||
		( n_txt_data.unicode == N_TXT_UNICODE_NIL )
	)
	{
		[_n_button_frmt n_enable:FALSE];
	} else {
		[_n_button_frmt n_enable:TRUE];
	}

	[_n_button_frmt display];


	[self NonnonCatPadTitle];

}

- (void) NonnonTxtbox_delegate_edited:(NonnonTxtbox*)txtbox onoff:(BOOL)onoff
{
//NSLog( @"NonnonTxtbox_delegate_edited" );

	if ( txtbox == _n_txtbox )
	{
//NSLog( @"NonnonTxtbox_delegate_edited : %d", onoff );

		if ( onoff == FALSE ) { return; }

		[self NonnonCatPadNekoAlternation:onoff];
		[_n_button_save display];


		[_n_button_dump n_enable:FALSE];
		[_n_button_dump display];

		dump_onoff = FALSE;


		[_n_button_html n_enable:FALSE];
		[_n_button_html display];

		 html_onoff = FALSE;

	} else {

		if ( _n_search.n_is_enter_pressed )
		{
			[self NonnonCatPadSettings:NO];

			n_posix_char *str = n_txt_get( _n_search.n_txt_data, 0 );
			[_n_txtbox NonnonTxtboxSearch:str is_reverse:NO];
		}

	}

}

- (void) NonnonTxtbox_delegate_find:(NonnonTxtbox*)txtbox
{
//NSLog( @"NonnonTxtbox_delegate_find" );

	// [!] : Ctrl + F

	if ( txtbox == _n_txtbox )
	{
		[_n_search NonnonTxtboxSelectAll:TRUE];
		[[_n_search window] makeFirstResponder:_n_search];
	} else {
		[[_n_txtbox window] makeFirstResponder:_n_txtbox];
	}

}

- (void) NonnonTxtbox_delegate_F3:(NonnonTxtbox*)txtbox is_left:(BOOL) is_left
{
//NSLog( @"NonnonTxtbox_delegate_F3" );

	n_posix_char *str = n_txt_get( _n_search.n_txt_data, 0 );

	[_n_txtbox NonnonTxtboxSearch:str is_reverse:( is_left == FALSE )];

	[self NonnonCatPadSettings:NO];

}

- (void) NonnonTxtbox_delegate_delete:(NonnonTxtbox*)txtbox
{
//NSLog( @"NonnonTxtbox_delegate_delete" );

	n_txt_set( _n_search.n_txt_data, 0, N_STRING_EMPTY );

	[self NonnonCatPadSettings:NO];

}

- (void) NonnonTxtbox_delegate_shift:(NSEvent*)event
{
//NSLog( @"NonnonTxtbox_delegate_shift" );
}




- (IBAction)n_info:(id)sender
{

	n_posix_char *unicode = n_posix_literal( "Unknown Format" );

	if ( n_txt_data.newline == N_TXT_NEWLINE_BINARY )
	{
		//
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_NIL )
	{
		unicode = n_posix_literal( "Non-Unicode" );
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_UTF8_NO_BOM )
	{
		unicode = n_posix_literal( "UTF-8 without BOM" );
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_UTF )
	{
		unicode = n_posix_literal( "UTF-8 with BOM" );
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_LIL )
	{
		unicode = n_posix_literal( "Unicode Little Endian" );
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_BIG )
	{
		unicode = n_posix_literal( "Unicode Big Endian" );
	}


	n_posix_char *newline = n_posix_literal( "Binary" );

	if ( n_txt_data.newline == N_TXT_NEWLINE_CRLF )
	{
		newline = n_posix_literal( "CRLF" );
	} else
	if ( n_txt_data.newline == N_TXT_NEWLINE_CR )
	{
		newline = n_posix_literal( "CR" );
	} else
	if ( n_txt_data.newline == N_TXT_NEWLINE_LF )
	{
		newline = n_posix_literal( "LF" );
	}


	n_posix_char *pth = n_mac_nsstring2str( _n_txtbox.n_path );
	n_type_int    cch = n_posix_strlen( pth ) + 1024;
	n_posix_char *str = n_string_new( cch );

	n_posix_sprintf_literal( str, "%s\n\n%s (%s)", pth, unicode, newline );

	n_mac_window_dialog_ok( str );

	n_string_free( str );
	n_string_free( pth );

}



/*
- (NSApplicationTerminateReply) applicationShouldTerminate:(NSApplication*) sender
{

	// [x] : buggy : when once cancelled, pressing window close button calls this method

	BOOL shouldQuit = n_mac_window_dialog_yesno( "Quit? (you press Command+Q)" );
	if ( shouldQuit )
	{
		return NSTerminateNow;
	} else {
		return NSTerminateCancel;
	}

}
*/



- (IBAction)n_catpad_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"catpad" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}




- (IBAction)n_formatter_go_method:(id)sender {


	int prev_charset = n_txt_data.unicode;
	int prev_newline = n_txt_data.newline;


	int index = (int) [_n_formatter_combo_charset indexOfSelectedItem];

	if ( index == 0 )
	{
		n_txt_data.unicode = N_TXT_UNICODE_LIL;
	} else
	if ( index == 1 )
	{
		n_txt_data.unicode = N_TXT_UNICODE_BIG;
	} else
	if ( index == 2 )
	{
		n_txt_data.unicode = N_TXT_UNICODE_UTF;
	} else
	if ( index == 3 )
	{
		n_txt_data.unicode = N_TXT_UNICODE_UTF8_NO_BOM;
	}// else


	index = (int) [_n_formatter_combo_newline indexOfSelectedItem];

	if ( index == 0 )
	{
		n_txt_data.newline = N_TXT_NEWLINE_CRLF;
	} else
	if ( index == 1 )
	{
		n_txt_data.newline = N_TXT_NEWLINE_CR;
	} else
	if ( index == 2 )
	{
		n_txt_data.newline = N_TXT_NEWLINE_LF;
	}


	if (
		( prev_charset != n_txt_data.unicode )
		||
		( prev_newline != n_txt_data.newline )
	)
	{
		[self NonnonCatPadNekoAlternation:TRUE];
		[_n_button_save display];
	}


	if ( n_sheet_used )
	{
		[_window endSheet:_n_formatter_window];
	} else {
		n_mac_window_hide( _n_formatter_window );
	}

}

- (IBAction)n_formatter_cancel_method:(id)sender {

	if ( n_sheet_used )
	{
		[_window endSheet:_n_formatter_window];
	} else {
		n_mac_window_hide( _n_formatter_window );
	}

}




- (IBAction)n_volume_go_method:(id)sender {

	volume = [_n_volume_slider intValue];

	[self NonnonCatPadSettings:NO];

	[_window endSheet:_n_volume_window];

}

- (IBAction)n_volume_cancel_method:(id)sender {

	[_window endSheet:_n_volume_window];

}

- (IBAction)n_volume_slider_method:(id)sender {

//NSLog( @"%d", (int) [sender integerValue] );

	[self NonnonCatPadVolumeLabel:(int) [sender integerValue]];

}


@end
