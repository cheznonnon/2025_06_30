//
//  AppDelegate.h
//  Pen Trainer
//
//  Created by のんのん on 2023/02/02.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

